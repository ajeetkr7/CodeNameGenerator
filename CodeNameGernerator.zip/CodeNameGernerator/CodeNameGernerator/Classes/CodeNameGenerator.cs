﻿using CodeNameGernerator.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeNameGernerator.Classes
{
    public class CodeNameGenerator : ICodeNameGenerator
    {
        public string GetCodeName(char nameFirstChar, Dictionary<char, string> codeNames)
        {
            string codeName = string.Empty;
            codeName = "******";
            //get the value for key nameFirstChar in codeNames

            return codeName;
        }
    }
}
