﻿using CodeNameGernerator.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeNameGernerator.Classes
{
    public class FirstNameList : IFirstNameList
    {
        public Dictionary<char, string> GetFirstNameList()
        {
            Dictionary<char, string> firstNames = new Dictionary<char, string>();
            ///add all key value list

            return firstNames;
        }
    }
}
