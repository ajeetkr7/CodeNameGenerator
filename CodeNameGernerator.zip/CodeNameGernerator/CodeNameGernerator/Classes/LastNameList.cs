﻿using CodeNameGernerator.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeNameGernerator.Classes
{
    public class LastNameList : ILastNameList
    {
        public Dictionary<char, string> GetLastNameList()
        {
            Dictionary<char, string> lastNames = new Dictionary<char, string>();
            //Add key value pair list

            return lastNames;
        }
    }
}
