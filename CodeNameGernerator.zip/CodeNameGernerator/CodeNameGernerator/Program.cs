﻿using CodeNameGernerator.Classes;
using CodeNameGernerator.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeNameGernerator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter first charcter of your first name (for eg If your name Sky Trooper enter s)");
            var firstNameChar = Console.ReadLine()[0];
            Console.WriteLine("Please enter first charcter of your last name (for eg If your name Sky Trooper enter t)");
            var lastNameChar = Console.ReadLine()[0];

            IFirstNameList _firstNameList = new FirstNameList();
            ILastNameList _lastNameList = new LastNameList();
            Dictionary<char, string> firstNames = _firstNameList.GetFirstNameList();
            Dictionary<char, string> lastNames = _lastNameList.GetLastNameList();

            ICodeNameGenerator _codeNameGenerator = new CodeNameGenerator();
            string firstNameCode = _codeNameGenerator.GetCodeName(firstNameChar, firstNames);
            string lastNameCode = _codeNameGenerator.GetCodeName(lastNameChar, lastNames);

            Console.WriteLine("Your code name is :" + firstNameCode + " " + lastNameCode);

            Console.WriteLine("Please press any key to exit......");
            Console.ReadKey();
        }
    }
}
