﻿using System.Collections.Generic;

namespace CodeNameGernerator.Interfaces
{
    public interface ICodeNameGenerator
    {
        string GetCodeName(char nameFirstChar, Dictionary<char, string> codeNames);
    }
}
