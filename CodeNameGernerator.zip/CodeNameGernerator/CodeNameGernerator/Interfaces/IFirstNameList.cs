﻿using System.Collections.Generic;

namespace CodeNameGernerator.Interfaces
{
    public interface IFirstNameList
    {
        Dictionary<char, string> GetFirstNameList();
    }
}
