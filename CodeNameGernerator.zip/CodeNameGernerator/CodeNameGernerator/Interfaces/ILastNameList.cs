﻿using System.Collections.Generic;

namespace CodeNameGernerator.Interfaces
{
    public interface ILastNameList
    {
        Dictionary<char, string> GetLastNameList();
    }
}
